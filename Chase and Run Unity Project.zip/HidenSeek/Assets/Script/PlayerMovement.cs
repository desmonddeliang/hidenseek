﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour {
    float base_speed;
    // Use this for initialization
    void Start () {
        base_speed = 1f * Time.deltaTime;
    }
	
	// Update is called once per frame
	void Update () {
        if (GameObject.Find("Client_Object").GetComponent<client>().my_status%2==0 &
            GameObject.Find("Client_Object").GetComponent<client>().game_status == 1)
        {
            int counter = 0;
            if (Input.GetKey(KeyCode.D))
                counter++;
            if (Input.GetKey(KeyCode.A))
                counter++;
            if (Input.GetKey(KeyCode.W))
                counter++;
            if (Input.GetKey(KeyCode.S))
                counter++;

            
            if (counter != 2)
            {
                /* non diagnol */
                base_speed = 1.414213f * Time.deltaTime; 
            }
            
            if(GameObject.Find("Client_Object").GetComponent<client>().my_role == 0)
            {
                if(counter != 2)
                {
                    base_speed = 1.555634f * Time.deltaTime;
                } else
                {
                    base_speed = 1.1f * Time.deltaTime;
                }

            }

            if (Input.GetKey(KeyCode.D)) {
                if (transform.position.x < 6)
                {
                    Vector3 temp = new Vector3(base_speed, 0, 0);
                    transform.position += temp;
                }
            }
            if (Input.GetKey(KeyCode.A))
            {
                if (transform.position.x > -6)
                {
                    Vector3 temp = new Vector3(-base_speed, 0, 0);
                    transform.position += temp;
                }
            }
            if (Input.GetKey(KeyCode.W))
            {
                if (transform.position.y < 4)
                {
                    Vector3 temp = new Vector3(0, base_speed, 0);
                    transform.position += temp;
                }
            }
            if (Input.GetKey(KeyCode.S))
            {
                if (transform.position.y > -4)
                {
                    Vector3 temp = new Vector3(0, -base_speed, 0);
                    transform.position += temp;
                }
            }

        }
    }
}
