﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PeerMovement : MonoBehaviour {

    float base_speed = 0.04f;
    public Vector3 dst = new Vector3(0, 0, 0);

    // Use this for initialization
    void Start()
    {    
        transform.position = dst;
    }

    // Update is called once per frame
    void Update()
    {
        float step = base_speed;
        transform.position = Vector3.MoveTowards(transform.position, dst, step);
    }
}
